#pragma once
#include "antworld/core/world_runtime.hpp"
#include "antworld/core/rng.hpp"
#include "surface_internal.hpp"
#include "geometry_internal.hpp"
#include "contact_index.hpp"
#include "antworld/core/profiling.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <stdexcept>
#include <type_traits>

namespace antworld::detail {
inline void bump(std::uint64_t& n) {
    if (n == UINT64_MAX) throw std::overflow_error("monotonic counter exhausted");
    ++n;
}
inline std::uint64_t take(std::uint64_t& n) { const auto v = n; bump(n); return v; }
inline std::uint64_t add(std::uint64_t a, std::uint64_t b) {
    if (b > UINT64_MAX - a) throw std::overflow_error("mass overflow");
    return a + b;
}
inline FoodMass sum(FoodMass a, FoodMass b) {
    return {add(a.carbs_ug, b.carbs_ug), add(a.protein_ug, b.protein_ug),
        add(a.water_ug, b.water_ug), add(a.other_ug, b.other_ug)};
}
inline FoodMass subtract(FoodMass a, FoodMass b) {
    if (a.carbs_ug < b.carbs_ug || a.protein_ug < b.protein_ug ||
        a.water_ug < b.water_ug || a.other_ug < b.other_ug)
        throw std::logic_error("mass underflow");
    return {a.carbs_ug-b.carbs_ug, a.protein_ug-b.protein_ug,
        a.water_ug-b.water_ug, a.other_ug-b.other_ug};
}
FoodMass portion(FoodMass mass, std::uint64_t amount);
inline bool finite(PositionM p) { return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z); }
inline bool inside(PositionM p, const WorldConfig& c) {
    return finite(p) && p.x >= c.min_m.x && p.x <= c.max_m.x &&
        p.y >= c.min_m.y && p.y <= c.max_m.y && p.z >= c.min_m.z && p.z <= c.max_m.z;
}
inline void validate_config(const WorldConfig& c) {
    if (!finite(c.min_m) || !finite(c.max_m) || c.min_m.x >= c.max_m.x ||
        c.min_m.y >= c.max_m.y || c.min_m.z >= c.max_m.z ||
        !std::isfinite(c.max_speed_m_per_s) || c.max_speed_m_per_s <= 0 ||
        !std::isfinite(c.contact_distance_m) || c.contact_distance_m < 0)
        throw std::invalid_argument("invalid ENGINEERING_FIXTURE world configuration");
}
inline double distance(PositionM a, PositionM b) { return std::hypot(a.x-b.x, a.y-b.y, a.z-b.z); }
inline bool valid(Phase p) { return p <= Phase::Reschedule; }
inline bool valid(DiagnosticAction a) { return a <= DiagnosticAction::RepeatSameTime; }
inline bool valid(LifeStage a) { return a <= LifeStage::Dead; }

// Minimal grouped SoA: stable identity, lifecycle, spatial and material columns.
// Rows survive death. Stable IDs are not row indices. No mutable pointers escape.
struct AntStore {
    struct Identity { EntityId id; ColonyId colony; SimTime born; Caste caste; };
    struct Spatial { PositionM position; std::uint64_t revision; };
    struct Inventory { std::uint64_t capacity; FoodMass mass; };
    // Use the throwing count constructor: MSVC Debug allocates iterator proxies
    // even for empty vectors, but its default constructor is noexcept.
    std::vector<Identity> identities = std::vector<Identity>(0);
    std::vector<LifeStage> stages = std::vector<LifeStage>(0);
    std::vector<Spatial> spatial = std::vector<Spatial>(0);
    std::vector<Inventory> inventories = std::vector<Inventory>(0);
    std::map<EntityId, std::size_t> index;
    std::size_t size() const { return identities.size(); }
    AntState get(std::size_t i) const {
        const auto& a = identities[i]; const auto& p = spatial[i]; const auto& f = inventories[i];
        return {a.id, a.colony, a.born, stages[i], a.caste, p.position, p.revision, f.capacity, f.mass};
    }
    void set(std::size_t i, const AntState& a) noexcept {
        identities[i] = {a.id, a.colony, a.born_at, a.caste}; stages[i] = a.stage;
        spatial[i] = {a.position, a.position_revision}; inventories[i] = {a.carrying_capacity_ug, a.carried_food};
    }
    void append(const AntState& a) {
        const auto n = size();
        // Allocate all columns before changing logical row count.
        if (n == identities.capacity() || n == stages.capacity() || n == spatial.capacity() || n == inventories.capacity()) {
            const auto capacity = std::max<std::size_t>(8, n * 2 + 1);
            identities.reserve(capacity); stages.reserve(capacity); spatial.reserve(capacity); inventories.reserve(capacity);
        }
        if (!index.emplace(a.id, n).second) throw std::invalid_argument("duplicate ant ID");
        identities.push_back({a.id, a.colony, a.born_at, a.caste}); stages.push_back(a.stage);
        spatial.push_back({a.position, a.position_revision}); inventories.push_back({a.carrying_capacity_ug, a.carried_food});
    }
    void truncate(std::size_t n) noexcept {
        while (size() > n) { index.erase(identities.back().id); identities.pop_back(); }
        stages.resize(n); spatial.resize(n); inventories.resize(n);
    }
};
template <typename IdType, typename Row> struct Store {
    std::vector<Row> rows = std::vector<Row>(0);
    std::map<IdType, std::size_t> index;
    void append(Row row) {
        if (rows.size() == rows.capacity()) rows.reserve(std::max<std::size_t>(8, rows.size()*2+1));
        if (!index.emplace(row.id, rows.size()).second) throw std::invalid_argument("duplicate entity ID");
        rows.push_back(row);
    }
    void truncate(std::size_t n) noexcept {
        while (rows.size() > n) { index.erase(rows.back().id); rows.pop_back(); }
    }
};
std::uint64_t hash_bytes(std::span<const std::uint8_t> bytes);
std::uint64_t trace_hash(const std::vector<WorldEvent>& events);

// Undo only touched map entries. Reinsert retained nodes without allocating.
template <typename Map> class MapJournal {
    using Key = typename Map::key_type;
    using Value = typename Map::mapped_type;
    struct Change { Key key; Value before; bool inserted; typename Map::node_type removed; };
    Map& data;
    std::vector<Change> changes = std::vector<Change>(0);
    bool done{};
public:
    explicit MapJournal(Map& map) : data(map) { static_assert(std::is_nothrow_copy_assignable_v<Value>); }
    ~MapJournal() noexcept {
        profiling::Scope profile(profiling::Category::Transaction);
        if (done) { changes.clear(); return; }
        for (auto i = changes.rbegin(); i != changes.rend(); ++i) {
            if (i->inserted) data.erase(i->key);
            else if (i->removed) data.insert(std::move(i->removed));
            else data.find(i->key)->second = i->before;
        }
    }
    MapJournal(const MapJournal&) = delete;
    MapJournal& operator=(const MapJournal&) = delete;
    void set(const Key& key, const Value& value) {
        profiling::Scope profile(profiling::Category::Transaction);
        const auto it = data.find(key);
        if (it != data.end()) { changes.push_back({key, it->second, false, {}}); it->second = value; }
        else {
            Map prepared; prepared.emplace(key, value);
            changes.push_back({key, {}, true, {}}); data.insert(prepared.extract(key));
        }
    }
    void erase(const Key& key) {
        profiling::Scope profile(profiling::Category::Transaction);
        if (!data.contains(key)) return;
        changes.push_back({key, {}, false, {}}); changes.back().removed = data.extract(key);
    }
    void commit() noexcept { done = true; }
};
} // namespace antworld::detail

namespace antworld {
struct WorldRuntime::State {
    struct Metadata {
        SimTime now{};
        std::uint64_t revision{}, next_entity{1}, next_scheduled{1}, next_event{1}, next_sequence{1};
        Rng rng{0};
        std::optional<EventKey> watermark;
        std::uint64_t executed{}, living{};
        FoodLedger ledger;
        ForagingCounters foraging;
        ScheduledId maintenance;
        SoilLedger soil;
        std::uint64_t geometry_revision{};
        ContactWork contact_work;
        FoodMass physiology_inputs; // Derived conservative registration budget; rebuilt on restore.
        std::uint64_t initial_energy{}, maximum_yield{}, development_commands{}, resolution_commands{};
    } m;
    WorldId world;
    std::uint64_t seed;
    WorldConfig config;
    using Queue = std::map<EventKey, ScheduledEvent>;
    using QueueIndex = std::map<ScheduledId, EventKey>;
    Queue queue;
    QueueIndex queue_index;
    std::vector<WorldEvent> journal = std::vector<WorldEvent>(0);
    detail::AntStore ants;
    detail::Store<ColonyId, Colony> colonies;
    detail::Store<ResourceId, FoodSource> foods;
    std::shared_ptr<const detail::SurfaceDefinition> surface;
    using Foragers = std::map<EntityId, ForagerState>;
    using Trails = std::map<detail::TrailKey, detail::Trail>;
    using Visits = std::map<Cell, std::uint64_t>;
    using Edges = std::map<detail::EdgeKey, std::uint64_t>;
    using Discoveries = std::map<ResourceId, detail::Discovery>;
    using FoodCells = std::map<Cell, ResourceId>;
    Foragers foragers;
    Trails trails;
    Visits visits;
    Edges edges;
    Discoveries discoveries;
    FoodCells food_cells; // Derived local index; never exposed to the individual model.
    using Physiology = std::map<EntityId, PhysiologyState>;
    Physiology physiology;
    std::shared_ptr<const SocialConfig> social;
    std::shared_ptr<const LongTermConfig> long_term;
    using Reproduction = std::map<EntityId, ReproductionState>;
    using ResourceCycles = std::map<ResourceId, ResourceCycleState>;
    Reproduction reproduction;
    ResourceCycles resource_cycles;
    detail::ContactNodes contact_nodes;
    detail::ContactRoots contact_roots;
    using Autonomy = std::map<EntityId,AutonomyState>;
    Autonomy autonomy;
    std::shared_ptr<const detail::GeometryDefinition> geometry;
    detail::GeometryEdits geometry_edits;
    detail::EditIndex edit_index;
    detail::SpatialIndex spatial_index;
    using Parcels = std::map<SoilParcelId,SoilParcel>;
    using Carriers = std::map<EntityId,SoilParcelId>;
    using SoilRequests = std::map<ScheduledId,SoilRequest>;
    using Excavators = std::map<EntityId,ExcavatorState>;
    using SdfCache = std::map<PointQ,SdfBrick>;
    using DirtyBricks = std::map<PointQ,std::uint64_t>;
    Parcels parcels;
    Carriers carriers;
    SoilRequests soil_requests;
    Excavators excavators;
    SdfCache sdf_cache;
    DirtyBricks dirty_bricks;
    using Commands = std::map<CommandId, CommandReceipt>;
    Commands commands;
    using PendingConflicts = std::map<EntityId,std::array<std::uint64_t,2>>;
    PendingConflicts pending_conflicts; // Derived long-term per-actor development/resolution counts.
    [[nodiscard]] bool external_resolution(EntityId id) const {
        const auto entry=pending_conflicts.find(id);
        const auto count=entry==pending_conflicts.end()?0:entry->second[1];
        const std::array<ScheduledId,3> owned{
            physiology.contains(id)?physiology.at(id).behavior_event:ScheduledId{},
            foragers.contains(id)?foragers.at(id).action:ScheduledId{},
            excavators.contains(id)?excavators.at(id).action:ScheduledId{}};
        std::uint64_t known=0;
        for (std::size_t i=0;i<owned.size();++i) {
            bool unique=true; for (std::size_t j=0;j<i;++j) if (owned[i]==owned[j]) unique=false;
            if (unique && queue_index.contains(owned[i]) && queue_index.at(owned[i]).phase==Phase::Resolution) ++known;
        }
        if (known>count) throw std::logic_error("pending actor conflict index disagrees with ownership");
        return count>known;
    }
    State(WorldId id, std::uint64_t value, WorldConfig c = {}) : world(id), seed(value), config(c) { m.rng = Rng(value); }
    State(const State&) = delete;
    State& operator=(const State&) = delete;
};

// Rollback allocates no memory: removed queue nodes and touched row before-images
// are retained, and append-only stores/journal return to their original lengths.
class WorldRuntime::Transaction {
    struct QueueUndo {
        EventKey key; ScheduledId id; bool inserted;
        State::Queue::node_type event;
        State::QueueIndex::node_type index;
    };
    State& s;
    const RuntimeLimits& limits;
    State::Metadata before;
    std::shared_ptr<const detail::SurfaceDefinition> surface_before;
    std::shared_ptr<const detail::GeometryDefinition> geometry_before;
    std::shared_ptr<const SocialConfig> social_before;
    std::shared_ptr<const LongTermConfig> long_term_before;
    std::size_t ants_before, colonies_before, foods_before, journal_before;
    std::vector<QueueUndo> queue_undo = std::vector<QueueUndo>(0);
    std::vector<std::pair<std::size_t, AntState>> ant_undo = std::vector<std::pair<std::size_t, AntState>>(0);
    std::vector<std::pair<std::size_t, FoodSource>> food_undo = std::vector<std::pair<std::size_t, FoodSource>>(0);
    std::vector<std::pair<std::size_t, Colony>> colony_undo = std::vector<std::pair<std::size_t, Colony>>(0);
    bool committed{};
public:
    detail::MapJournal<State::Foragers> foragers;
    detail::MapJournal<State::Trails> trails;
    detail::MapJournal<State::Visits> visits;
    detail::MapJournal<State::Edges> edges;
    detail::MapJournal<State::Discoveries> discoveries;
    detail::MapJournal<State::FoodCells> food_cells;
    detail::MapJournal<State::Physiology> physiology;
    detail::MapJournal<detail::ContactNodes> contact_nodes;
    detail::MapJournal<detail::ContactRoots> contact_roots;
    detail::MapJournal<State::Autonomy> autonomy;
    detail::MapJournal<detail::GeometryEdits> geometry_edits;
    detail::MapJournal<detail::EditIndex> edit_index;
    detail::MapJournal<detail::SpatialIndex> spatial_index;
    detail::MapJournal<State::Parcels> parcels;
    detail::MapJournal<State::Carriers> carriers;
    detail::MapJournal<State::SoilRequests> soil_requests;
    detail::MapJournal<State::Excavators> excavators;
    detail::MapJournal<State::SdfCache> sdf_cache;
    detail::MapJournal<State::DirtyBricks> dirty_bricks;
    detail::MapJournal<State::Commands> commands;
    detail::MapJournal<State::Reproduction> reproduction;
    detail::MapJournal<State::ResourceCycles> resource_cycles;
    detail::MapJournal<State::PendingConflicts> pending_conflicts;
    Transaction(State& state, const RuntimeLimits& policy) : s(state), limits(policy), before(state.m), surface_before(state.surface),
        geometry_before(state.geometry), social_before(state.social), long_term_before(state.long_term),
        ants_before(s.ants.size()), colonies_before(s.colonies.rows.size()),
        foods_before(s.foods.rows.size()), journal_before(s.journal.size()), foragers(s.foragers), trails(s.trails),
        visits(s.visits), edges(s.edges), discoveries(s.discoveries), food_cells(s.food_cells), physiology(s.physiology),
        contact_nodes(s.contact_nodes), contact_roots(s.contact_roots), autonomy(s.autonomy),
        geometry_edits(s.geometry_edits), edit_index(s.edit_index), spatial_index(s.spatial_index), parcels(s.parcels), carriers(s.carriers),
        soil_requests(s.soil_requests), excavators(s.excavators), sdf_cache(s.sdf_cache), dirty_bricks(s.dirty_bricks), commands(s.commands),
        reproduction(s.reproduction), resource_cycles(s.resource_cycles), pending_conflicts(s.pending_conflicts) {}
    Transaction(const Transaction&) = delete;
    Transaction& operator=(const Transaction&) = delete;
    ~Transaction() noexcept {
        profiling::Scope profile(profiling::Category::Transaction);
        if (committed) { queue_undo.clear(); return; }
        for (auto i = ant_undo.rbegin(); i != ant_undo.rend(); ++i) s.ants.set(i->first, i->second);
        for (auto i = food_undo.rbegin(); i != food_undo.rend(); ++i) s.foods.rows[i->first] = i->second;
        for (auto i = colony_undo.rbegin(); i != colony_undo.rend(); ++i) s.colonies.rows[i->first] = i->second;
        s.ants.truncate(ants_before); s.colonies.truncate(colonies_before); s.foods.truncate(foods_before);
        s.journal.resize(journal_before);
        for (auto i = queue_undo.rbegin(); i != queue_undo.rend(); ++i) {
            if (i->inserted) { s.queue.erase(i->key); s.queue_index.erase(i->id); }
            else { s.queue.insert(std::move(i->event)); s.queue_index.insert(std::move(i->index)); }
        }
        s.m = before;
        s.surface = surface_before;
        s.geometry = geometry_before;
        s.social = social_before;
        s.long_term = long_term_before;
    }
    void commit() noexcept {
        profiling::Scope profile(profiling::Category::Transaction);
        committed = true; foragers.commit(); trails.commit(); visits.commit(); edges.commit(); discoveries.commit(); food_cells.commit(); physiology.commit();
        contact_nodes.commit(); contact_roots.commit(); autonomy.commit();
        geometry_edits.commit(); edit_index.commit(); spatial_index.commit(); parcels.commit(); carriers.commit();
        soil_requests.commit(); excavators.commit(); sdf_cache.commit(); dirty_bricks.commit();
        commands.commit();
        reproduction.commit(); resource_cycles.commit();
        pending_conflicts.commit();
    }
    void touch_ant(std::size_t i) { ant_undo.emplace_back(i, s.ants.get(i)); }
    void touch_food(std::size_t i) { food_undo.emplace_back(i, s.foods.rows[i]); }
    void touch_colony(std::size_t i) { colony_undo.emplace_back(i, s.colonies.rows[i]); }
    void entity_budget() const {
        if (s.ants.size() + s.colonies.rows.size() + s.foods.rows.size() + s.parcels.size() >= limits.entities)
            throw std::length_error("entity host budget exceeded");
    }
    ScheduledId insert(ScheduledEvent e) {
        profiling::Scope profile(profiling::Category::Scheduler);
        if (e.key.time < s.m.now || (e.key.time == s.m.now && s.m.watermark &&
            EventKey{e.key.time, e.key.phase, e.key.priority, e.key.tie, s.m.next_sequence} <= *s.m.watermark))
            throw std::invalid_argument("event precedes the persisted execution watermark");
        if (s.queue.size() >= limits.pending_events) throw std::length_error("future event host budget exceeded");
        e.id = {detail::take(s.m.next_scheduled)}; e.key.sequence = detail::take(s.m.next_sequence);
        State::Queue temporary; State::QueueIndex temporary_index;
        temporary.emplace(e.key, e); temporary_index.emplace(e.id, e.key);
        queue_undo.push_back({e.key, e.id, true, {}, {}});
        s.queue.insert(temporary.extract(e.key)); s.queue_index.insert(temporary_index.extract(e.id));
        if (e.kind == ScheduledEvent::Kind::Lifecycle && e.stage != LifeStage::Dead) detail::bump(s.m.development_commands);
        if (e.key.phase==Phase::Resolution) detail::bump(s.m.resolution_commands);
        if (s.long_term && e.actor.value && ((e.kind==ScheduledEvent::Kind::Lifecycle && e.stage!=LifeStage::Dead) || e.key.phase==Phase::Resolution)) {
            auto counts=s.pending_conflicts.contains(e.actor)?s.pending_conflicts.at(e.actor):std::array<std::uint64_t,2>{};
            detail::bump(counts[e.key.phase==Phase::Resolution?1:0]); pending_conflicts.set(e.actor,counts);
        }
        detail::bump(s.m.revision); return e.id;
    }
    ScheduledEvent remove(EventKey key) {
        profiling::Scope profile(profiling::Category::Scheduler);
        const auto e = s.queue.at(key);
        queue_undo.push_back({key, e.id, false, {}, {}});
        queue_undo.back().event = s.queue.extract(key); queue_undo.back().index = s.queue_index.extract(e.id);
        if (e.kind == ScheduledEvent::Kind::Lifecycle && e.stage != LifeStage::Dead) --s.m.development_commands;
        if (e.key.phase==Phase::Resolution) --s.m.resolution_commands;
        if (s.long_term && e.actor.value && ((e.kind==ScheduledEvent::Kind::Lifecycle && e.stage!=LifeStage::Dead) || e.key.phase==Phase::Resolution)) {
            auto counts=s.pending_conflicts.at(e.actor); --counts[e.key.phase==Phase::Resolution?1:0];
            if (counts[0] || counts[1]) pending_conflicts.set(e.actor,counts); else pending_conflicts.erase(e.actor);
        }
        return e;
    }
    void time(SimTime at) {
        if (at != s.m.now) { s.m.now = at; s.m.watermark.reset(); s.m.executed = 0; }
    }
    void executing(const ScheduledEvent& e) {
        time(e.key.time);
        if (s.m.executed >= limits.events_per_timestamp)
            throw std::runtime_error("same-time event host budget exceeded; advance rolled back");
        ++s.m.executed; s.m.watermark = e.key;
    }
    void fact(WorldEvent e) {
        profiling::Scope profile(profiling::Category::History);
        if (s.journal.size() >= limits.committed_events) throw std::length_error("committed event host budget exceeded");
        e.id = {detail::take(s.m.next_event)}; e.world = s.world; e.time = s.m.now;
        detail::bump(s.m.revision); e.revision = s.m.revision; s.journal.push_back(e);
    }
};
} // namespace antworld
